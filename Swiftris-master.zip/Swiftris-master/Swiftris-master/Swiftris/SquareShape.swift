//
//  SquareShape.swift
//  Swiftris
//
//  Created by Christina Saylor on 3/7/17.
//  Copyright © 2017 Christina Saylor. All rights reserved.
//

class SquareShape:Shape {
  //since the square shape will be identical at all orientations, it does not rotate
    
    //Each index of the arrays represents one of the four blocks ordered from 0 to 3
    override var blockRowColumnPositions:[Orientation: Array<(columnDiff: Int, rowDiff: Int)>] {
        return [
            Orientation.zero: [(0,0), (1,0), (0,1), (1,1)],
            Orientation.oneEighty: [(0,0), (1,0), (0,1), (1,1)],
            Orientation.ninety: [(0,0), (1,0), (0,1), (1,1)],
            Orientation.twoSeventy: [(0,0), (1,0), (0,1), (1,1)]
                ]
    }
    
    //Since the square shape does not rotate, it's bottom-most blocks are always the third and fourth blocks
    override var
bottomBlocksForOrientations: [Orientation : Array<Block>] {
        return [
            Orientation.zero: [blocks[ThirdBlockIdx], blocks[FourthBlockIdx]],
            Orientation.oneEighty: [blocks[ThirdBlockIdx], blocks[FourthBlockIdx]],
            Orientation.ninety: [blocks[ThirdBlockIdx], blocks[FourthBlockIdx]],
            Orientation.twoSeventy: [blocks[ThirdBlockIdx], blocks[FourthBlockIdx]]
        ]
    }
}
