//
//  Graffiti.swift
//  Swiftris
//
//  Created by Christina Saylor on 3/29/17.
//  Copyright © 2017 Christina Saylor. All rights reserved.
//

import UIKit

let Graffiticolor: UInt32 = 6






enum GraffitiColor: Int, CustomStringConvertible {
    
    
    
    
    
    
    case blue = 0, orange, purple, red, teal,yellow
    
    var spriteName: String {
        switch self {
        case.blue:
            return "graffiti-blue"
        case.orange:
            return "graffiti-orange"
        case.purple:
            return "graffiti-purple"
        case.red:
            return "graffiti-red"
        case.teal:
            return "graffiti-teal"
        case.yellow:
            return "graffiti-yellow"
            
        }
    }
    
    
    var description: String{
        return self.spriteName
    }
    
    //returns a random choice among the colors found in BlockColor.
    static func random() ->GraffitiColor {
        return
            
            GraffitiColor(rawValue:Int(arc4random_uniform(Graffiticolor)))!
    }
    
}


class Graffiti: Hashable, CustomStringConvertible {

    
    
    
    
    
    
    
    
    
    
    
    
    //Once a color is assigned, it can no longer be reassigned. Blocks cannot change color mid-game
    var color: GraffitiColor
    
    
    
    
    
    //the column and row represent the location of the Block on the game board
    var column: Int
    var row: Int
    //SKSpriteNode represents the visual element of the Block which GameScene will use to render and animate each Block
    var sprite: SKSpriteNode?
    
    var spriteName: String {
        return color.spriteName
    }
    
    //returns the exclusive-or of the "row" and "column" properties to generate a unique integer for each Block
    var hashValue: Int {
        return self.column ^ self.row
    }
    
    var description: String {
        return "\(color): [\(column), \(row)]"
    }
    
    init(column:Int, row:Int, color:GraffitiColor) {
        self.column = column
        self.row = row
        self.color = color
    }
    
}

//compares one block with another. Returns true if both blocks are in the same location and of the same color
func ==(lhs: Graffiti, rhs: Graffiti) -> Bool {
    return lhs.column == rhs.column && lhs.row == rhs.row && lhs.color.rawValue == rhs.color.rawValue
}
