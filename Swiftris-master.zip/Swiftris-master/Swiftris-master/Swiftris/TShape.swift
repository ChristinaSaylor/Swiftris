//
//  TShape.swift
//  Swiftris
//
//  Created by Christina Saylor on 3/7/17.
//  Copyright © 2017 Christina Saylor. All rights reserved.
//

class TShape:Shape {
    override var blockRowColumnPositions: [Orientation : Array<(columnDiff: Int, rowDiff: Int)>] {
        return [
            Orientation.zero: [(1,0), (0,1), (1,1), (2,1)],
            Orientation.ninety: [(2,1), (1,0), (1,1), (1,2)],
            Orientation.oneEighty: [(1,2), (0,1), (1,1), (2,1)],
            Orientation.twoSeventy: [(0,1),(1,0),(1,1),(1,2)]
        ]
    }
    
    override var bottomBlocksForOrientations: [Orientation : Array<Block>] {
        return [
            Orientation.zero: [blocks[SecondBlockIdx], blocks[ThirdBlockIdx], blocks[FourthBlockIdx]],
            Orientation.ninety: [blocks[FirstBlockIdx], blocks[FourthBlockIdx]],
            Orientation.oneEighty: [blocks[FirstBlockIdx], blocks[SecondBlockIdx], blocks[FourthBlockIdx]],
            Orientation.twoSeventy: [blocks[FirstBlockIdx], blocks[FourthBlockIdx]]
        ]
    }
}
