//
//  GameScene.swift
//  Swiftris
//
//  Created by Christina Saylor on 3/6/17.
//  Copyright (c) 2017 Christina Saylor. All rights reserved.
//

import SpriteKit

//define the point size of each block sprite
let BlockSize:CGFloat = 20.0



//The slowest speed at which the shapes will travel (decends by one row every 6/10ths of a second
let TickLengthLevelOne = TimeInterval(600)



class GameScene: SKScene {
    
    let gameLayer = SKNode()
    let shapeLayer = SKNode()
    let LayerPosition = CGPoint(x: 6, y: -6)
    
    //this is a closure. Basically a function. The empty parenthesis mean that it takes no parameters and returns nothing. The question mark means that it's optional and may be nil (null)
    var tick:(() -> ())?
    
    var tickLengthMillis = TickLengthLevelOne
    
    var lastTick:Date?
    
    var textureCache = Dictionary<String, SKTexture>()
    
    var background = SKSpriteNode(imageNamed: "background")
    
    required init(coder aDecoder: NSCoder) {
        fatalError("NSCoder not supported")
    }
    
    override init(size: CGSize) {
        super.init(size: size)
        
        anchorPoint = CGPoint(x: 0, y: 1.0)
        
        
        
        background.position = CGPoint(x: 0, y:0)
        
        
        
        background.anchorPoint = CGPoint(x: 0, y: 1.0)
        
        addChild(background)
        
        addChild(gameLayer)
        
        let gameBoardTexture = SKTexture(imageNamed: "gameboard")
        
        let gameBoard = SKSpriteNode(texture: gameBoardTexture, size: CGSize(width: BlockSize * CGFloat(NumColumns), height: BlockSize * CGFloat(NumRows)))
        
        gameBoard.anchorPoint = CGPoint(x:0,y:1.0)
        gameBoard.position = LayerPosition
        
        shapeLayer.position = LayerPosition
        shapeLayer.addChild(gameBoard)
        gameLayer.addChild(shapeLayer)
        

    }
    
    func playSound(_ sound:String) {
        run(SKAction.playSoundFileNamed(sound, waitForCompletion: false))
    }
    
    override func update(_ currentTime: TimeInterval) {
        
        //"guard" checks the conditions that follow it. If the conditions fail, it executes the else block
        //if lastTick is missing, the game is in a paused state and not reporting elapsed ticks, so we return
        guard let lastTick = lastTick
            else {
                return
        }
        //if lastTick is present, we recover the time passed since the last execution of update by invoking timeIntervalSinceNow on lastTick. Multiply the result by -1000 to get a positive millisecond value
        let timePassed = lastTick.timeIntervalSinceNow * -1000.0

        if timePassed > tickLengthMillis
        {
            self.lastTick = Date()
            tick?()
        }
    }
    
    func startTicking() {
        lastTick = Date()
    }
    
    func stopTicking() {
        lastTick = nil
    }
    
    //returns the precise coordinate on the screen for where a block sprite belongs based on its row and column position
    func pointForColumn(_ column: Int, row: Int) -> CGPoint {
        let x = LayerPosition.x + (CGFloat(column) * BlockSize) + (BlockSize / 2)
        let y = LayerPosition.y - ((CGFloat(row) * BlockSize) + (BlockSize / 2))
        
        return CGPoint(x: x, y: y)
    }
    
    func addPreviewShapeToScene(_ shape:Shape, completion:@escaping () -> ()) {
        for block in shape.blocks {
            var texture = textureCache[block.spriteName]
            
            if texture == nil {
                texture = SKTexture(imageNamed: block.spriteName)
                
                textureCache[block.spriteName] = texture
            }
            
            let sprite = SKSpriteNode(texture: texture)
            
            //place each block's sprite in the proper location
            //start at row - 2 so that the preview piece animates smoothly into place from a higher location
            sprite.position = pointForColumn(block.column, row:block.row - 2)
            
            shapeLayer.addChild(sprite)
            block.sprite = sprite
            
            //animation
            sprite.alpha = 0
            
            //SKAction objects are responsible for visually manipulating SKNode objects
            //Each block will fade and move into place as it appears as part of the next piece. It will move two rows down and fade from complete transparency to 70% opacity
            let moveAction = SKAction.move(to: pointForColumn(block.column, row: block.row), duration: TimeInterval(0.2))
            
            moveAction.timingMode = .easeOut
            
            let fadeInAction = SKAction.fadeAlpha(to: 0.7, duration: 0.4)
            
            fadeInAction.timingMode = .easeOut

            sprite.run(SKAction.group ([moveAction, fadeInAction]))
        }
        
        run(SKAction.wait(forDuration: 0.4), completion: completion)
    }
    
    func movePreviewShape(_ shape:Shape, completion:@escaping () -> ()) {
        for block in shape.blocks {
            let sprite = block.sprite!
            let moveTo = pointForColumn(block.column, row:block.row)
            let moveToAction:SKAction = SKAction.move(to: moveTo, duration: 0.2)
            moveToAction.timingMode = .easeOut
            sprite.run(
                SKAction.group([moveToAction, SKAction.fadeAlpha(to: 1.0, duration: 0.2)]), completion: {})
        }
        
        run(SKAction.wait(forDuration: 0.2), completion: completion)
    }
    
    func redrawShape(_ shape:Shape, completion:@escaping () -> ()) {
        for block in shape.blocks {
            let sprite = block.sprite!
            
            let moveTo = pointForColumn(block.column, row:block.row)
            
            let moveToAction:SKAction = SKAction.move(to: moveTo, duration: 0.05)
            moveToAction.timingMode = .easeOut
            
            if block == shape.blocks.last {
                sprite.run(moveToAction, completion: completion)
            } else {
                sprite.run(moveToAction)
            }
        }
    }
    
    func animateCollapsingLines(_ linesToRemove: Array<Array<Block>>, fallenBlocks: Array<Array<Block>>, completion:@escaping () -> ()) {
        
        var longestDuration: TimeInterval = 0
        
        for (columnIdx, column) in fallenBlocks.enumerated() {
            for (blockIdx, block) in column.enumerated() {
                let newPosition = pointForColumn(block.column, row: block.row)
                
                let sprite = block.sprite!
                
                let delay = (TimeInterval(columnIdx) * 0.05) + (TimeInterval(blockIdx) * 0.05)
                
                let duration = TimeInterval(((sprite.position.y - newPosition.y) / BlockSize) * 0.1)
                
                let moveAction = SKAction.move(to: newPosition, duration: duration)
                
                moveAction.timingMode = .easeOut
                
                sprite.run (
                
                    SKAction.sequence([
                        
                        SKAction.wait(forDuration: delay), moveAction
                        
                        ])
                )
                
                longestDuration = max(longestDuration, duration + delay)
                
            }
        }
        
        for rowToRemove in linesToRemove {
            for block in rowToRemove {
                let randomRadius = CGFloat(UInt(arc4random_uniform(400) + 100))
                
                let goLeft = arc4random_uniform(100) % 2 == 0
                
                var point = pointForColumn(block.column, row: block.row)
                
                point = CGPoint(x: point.x + (goLeft ? -randomRadius : randomRadius), y: point.y)
                
                let randomDuration = TimeInterval(arc4random_uniform(2)) + 0.5
                
                var startAngle = CGFloat(M_PI)
                var endAngle = startAngle * 2
                if goLeft {
                    endAngle = startAngle
                    
                    startAngle = 0
                }
                
                let archPath = UIBezierPath(arcCenter: point, radius: randomRadius, startAngle: startAngle, endAngle: endAngle, clockwise: goLeft)
                
                let archAction = SKAction.follow(archPath.cgPath, asOffset: false, orientToPath: true, duration: randomDuration)
                
                archAction.timingMode = .easeIn
                let sprite = block.sprite!
                
                sprite.zPosition = 100
                sprite.run(
                    SKAction.sequence(
                        [SKAction.group([archAction, SKAction.fadeOut(withDuration: TimeInterval(randomDuration))]),
                        SKAction.removeFromParent()]
                    )
                )
            }
        }
        
        run(SKAction.wait(forDuration: longestDuration), completion:completion)
    }
    
}
